package com.example.grocery_deliverys

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
